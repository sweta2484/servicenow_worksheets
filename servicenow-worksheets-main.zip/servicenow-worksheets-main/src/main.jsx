import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'
console.log('%cFlare Worksheets build 4-15-2025','color:blue')
ReactDOM.createRoot(document.getElementById('root')).render(
    <App />,
)
